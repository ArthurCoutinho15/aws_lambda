def log(mensagem):
    return print('Adicionando log via função', mensagem)